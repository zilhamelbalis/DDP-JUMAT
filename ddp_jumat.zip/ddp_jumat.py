print("Nama:Zilha Melbalis")
print("Nim:0110124026")
print("Rombel:SI 08")
print("Asdos:Saya")